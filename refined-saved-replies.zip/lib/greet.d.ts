import { GreetOptions } from "./types.js";
export declare function greet(options: GreetOptions | string): void;
//# sourceMappingURL=greet.d.ts.map