export {};
//# sourceMappingURL=greet.test.d.ts.map