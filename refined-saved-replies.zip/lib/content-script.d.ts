export {};
//# sourceMappingURL=content-script.d.ts.map