export type CreateElementAttributes = Record<string, unknown> & {
    children?: (Node | string)[];
    className?: string;
};
export declare function createElement<TagName extends keyof HTMLElementTagNameMap>(tagName: TagName, { children, className, ...attributes }?: CreateElementAttributes): HTMLElementTagNameMap[TagName];
//# sourceMappingURL=elements.d.ts.map