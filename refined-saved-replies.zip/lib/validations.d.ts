import { BodyWithReplies, RepositoryDetails } from "./types.js";
export declare function isBodyWithReplies(data: unknown): data is BodyWithReplies;
export declare function isRepositoryDetails(data: unknown): data is RepositoryDetails;
//# sourceMappingURL=validations.d.ts.map